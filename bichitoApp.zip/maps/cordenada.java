package maps;

public class cordenada {
  public double lat;
  public double lonj;
}