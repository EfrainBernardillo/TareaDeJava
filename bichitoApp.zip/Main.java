import java.util.*;
import java.lang.Math;
import maps.cordenada; //aqui importa una clase

class Main {

  public static void main(String[] args) {
  System.out.println("\n");

  maps();

}

  public static void maps(){

    ArrayList<cordenada> lista = 
    new ArrayList<cordenada>();

  double Latitud, Longitud;
  int CD;

  Scanner primero = new Scanner(System.in);

System.out.println("Ingresa aqui la cantidad de cordinadas: ");
System.out.println("======================");

CD = primero.nextInt();

for (int x = 0; x < nDatos; x++) {
System.out.println("");
System.out.println("DATO" + (x + 1));
System.out.println("");
System.out.println("latitud: " + (x + 1));

Latitud = primero.nextDouble();
System.out.println("longitud: " + (x + 1));

Longitud = primero.nextDouble();

cordenada o = new cordenada();
o.lat = Latitud;
o.lonj = Longitud;

lista.add(x, o);
 }

System.out.println("\nAqui tienes la ubicacion de tus coordenadas:");
System.out.println("===============================");

System.out.println("https://www.keene.edu/campus/maps/tool/?coordinates=");

for (int x = 0; x <= CD; x++) {
if (x != nDatos) {

System.out.print(lista.get(x).lat);
System.out.print("%2C%20");
System.out.print(lista.get(x).lonj);
System.out.print("%0A");

} else {
  
System.out.print(lista.get(0).lat);
System.out.print("%2C%20");
System.out.print(lista.get(0).lonj);

}
}
}

}



