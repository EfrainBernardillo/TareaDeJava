package clases;

public class titulado{
  public String zip;
  public String colegio;
}
