package clases;

public class interino extends profesor {
  public String codigo;
  public String invitado;
}