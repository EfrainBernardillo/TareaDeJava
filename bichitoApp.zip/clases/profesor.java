package clases;

public class profesor {
  public String id;
  public String first_name;
  public String last_name;
}
